/*
  Copyright (c), 2001-2024, Shenshu Tech. Co., Ltd.
 */

#include <stdio.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>

#ifdef OT_GPIO_I2C
#include "gpioi2c_ex.h"
#else
#include "ot_i2c.h"
#endif
#include "securec.h"

#include "isr2006_cmos.h"
#include "ot_mpi_isp.h"
#include "ot_sns_ctrl.h"

#define I2C_DEV_FILE_NUM 16
#define I2C_BUF_NUM 8

static int g_fd[OT_ISP_MAX_PIPE_NUM] = {[0 ...(OT_ISP_MAX_PIPE_NUM - 1)] = -1};

int isr2006_i2c_init(ot_vi_pipe vi_pipe)
{
    if (g_fd[vi_pipe] >= 0)
    {
        return TD_SUCCESS;
    }
#ifdef OT_GPIO_I2C
    g_fd[vi_pipe] = open("/dev/gpioi2c_ex", O_RDONLY, S_IRUSR);
    if (g_fd[vi_pipe] < 0)
    {
        isp_err_trace("Open gpioi2c_ex error!\n");
        return TD_FAILURE;
    }
#else
    int ret;
    char dev_file[I2C_DEV_FILE_NUM] = {0};
    td_u8 dev_num;
    ot_isp_sns_commbus *isr2006businfo = TD_NULL;
    isr2006businfo = isr2006_get_bus_info(vi_pipe);
    dev_num = isr2006businfo->i2c_dev;
    (td_void) snprintf_s(dev_file, sizeof(dev_file), sizeof(dev_file) - 1, "/dev/i2c-%u", dev_num);

    g_fd[vi_pipe] = open(dev_file, O_RDWR, S_IRUSR | S_IWUSR);
    if (g_fd[vi_pipe] < 0)
    {
        isp_err_trace("Open /dev/ot_i2c_drv-%u error!\n", dev_num);
        return TD_FAILURE;
    }

    ret = ioctl(g_fd[vi_pipe], OT_I2C_SLAVE_FORCE, (ISR2006_I2C_ADDR >> 1));
    if (ret < 0)
    {
        isp_err_trace("I2C_SLAVE_FORCE error!\n");
        close(g_fd[vi_pipe]);
        g_fd[vi_pipe] = -1;
        return ret;
    }
#endif

    return TD_SUCCESS;
}

int isr2006_i2c_exit(ot_vi_pipe vi_pipe)
{
    if (g_fd[vi_pipe] >= 0)
    {
        close(g_fd[vi_pipe]);
        g_fd[vi_pipe] = -1;
        return TD_SUCCESS;
    }
    return TD_FAILURE;
}

td_s32 isr2006_read_register(ot_vi_pipe vi_pipe, td_u32 addr)
{
    ot_unused(vi_pipe);
    ot_unused(addr);
    return TD_SUCCESS;
}

td_s32 isr2006_write_register(ot_vi_pipe vi_pipe, td_u32 addr, td_u32 data)
{
    td_s32 ret;
    if (g_fd[vi_pipe] < 0)
    {
        return TD_SUCCESS;
    }

#ifdef OT_GPIO_I2C
    i2c_data.dev_addr = ISR2006_I2C_ADDR;
    i2c_data.reg_addr = addr;
    i2c_data.addr_byte_num = ISR2006_ADDR_BYTE;
    i2c_data.data = data;
    i2c_data.data_byte_num = ISR2006_DATA_BYTE;

    ret = ioctl(g_fd[vi_pipe], GPIO_I2C_WRITE, &i2c_data);
    if (ret)
    {
        isp_err_trace("GPIO-I2C write failed!\n");
        return ret;
    }
#else
    td_u32 idx = 0;
    td_u8 buf[I2C_BUF_NUM];

    if (ISR2006_ADDR_BYTE == 2)
    {                                  /* 2 byte */
        buf[idx] = (addr >> 8) & 0xff; /* shift 8 */
        idx++;
        buf[idx] = addr & 0xff;
        idx++;
    }
    else
    {
    }

    if (ISR2006_DATA_BYTE == 2)
    { /* 2 byte */
    }
    else
    {
        buf[idx] = data & 0xff;
        idx++;
    }

    ret = write(g_fd[vi_pipe], buf, ISR2006_ADDR_BYTE + ISR2006_DATA_BYTE);
    if (ret < 0)
    {
        isp_err_trace("I2C_WRITE error!\n");
        return TD_FAILURE;
    }

#endif
    return TD_SUCCESS;
}

static void delay_ms(int ms)
{
    usleep(ms * 1000); /* 1ms: 1000us */
    return;
}

void isr2006_prog(ot_vi_pipe vi_pipe, const td_u32 *rom)
{
    ot_unused(vi_pipe);
    ot_unused(rom);
    return;
}

void isr2006_standby(ot_vi_pipe vi_pipe)
{
    td_s32 ret = TD_SUCCESS;
    ret += isr2006_write_register(vi_pipe, 0x00a6, 0x00);
    // ret += isr2006_write_register(vi_pipe, 0x3000, 0x01);  /* STANDBY */
    // ret += isr2006_write_register(vi_pipe, 0x3002, 0x01);  /* XTMSTA */
    if (ret != TD_SUCCESS)
    {
        isp_err_trace("write register failed!\n");
    }
    return;
}

void isr2006_restart(ot_vi_pipe vi_pipe)
{
    td_s32 ret = TD_SUCCESS;
    ret += isr2006_write_register(vi_pipe, 0x00a6, 0x01);
    delay_ms(18); /* 18ms */
    // ret += isr2006_write_register(vi_pipe, 0x3000, 0x00);  /* standby */
    // delay_ms(18); /* 18ms */
    // ret += isr2006_write_register(vi_pipe, 0x3002, 0x00);  /* master mode start */
    if (ret != TD_SUCCESS)
    {
        isp_err_trace("write register failed!\n");
    }
    return;
}

void isr2006_mirror_flip(ot_vi_pipe vi_pipe, ot_isp_sns_mirrorflip_type sns_mirror_flip)
{
    switch (sns_mirror_flip)
    {
    case ISP_SNS_NORMAL:
        isr2006_write_register(vi_pipe, 0x304E, 0x0);
        break;
    case ISP_SNS_MIRROR:
        isr2006_write_register(vi_pipe, 0x304E, 0x1);
        break;
    default:
        break;
    }
    return;
}

void isr2006_blc_clamp(ot_vi_pipe vi_pipe, ot_isp_sns_blc_clamp sns_blc_clamp)
{
    td_s32 ret = TD_SUCCESS;

    isr2006_set_blc_clamp_value(vi_pipe, sns_blc_clamp.blc_clamp_en);

    if (sns_blc_clamp.blc_clamp_en == TD_TRUE)
    {
        ret += isr2006_write_register(vi_pipe, 0x00e2, 0x01);
        // ret += isr2006_write_register(vi_pipe, 0x3280, 0x01);  /* clamp on */
    }
    else
    {
        ret += isr2006_write_register(vi_pipe, 0x00e2, 0x00);
        // ret += isr2006_write_register(vi_pipe, 0x3280, 0x00);  /* clamp off */
        // ret += isr2006_write_register(vi_pipe, 0x3302, 0x36);
    }

    if (ret != TD_SUCCESS)
    {
        isp_err_trace("write register failed!\n");
    }
    return;
}

static void isr2006_linear_1936_1280_30_init(ot_vi_pipe vi_pipe);

static void isr2006_default_reg_init(ot_vi_pipe vi_pipe)
{
    td_u32 i;
    td_s32 ret = TD_SUCCESS;
    ot_isp_sns_state *pastisr2006 = TD_NULL;
    pastisr2006 = isr2006_get_ctx(vi_pipe);
    for (i = 0; i < pastisr2006->regs_info[0].reg_num; i++)
    {
        ret += isr2006_write_register(vi_pipe, pastisr2006->regs_info[0].i2c_data[i].reg_addr,
                                      pastisr2006->regs_info[0].i2c_data[i].data);
    }
    if (ret != TD_SUCCESS)
    {
        isp_err_trace("write register failed!\n");
    }
    return;
}

// void isr2006_set_slave_registers(ot_vi_pipe vi_pipe)
// {
//     // td_s32 slave_dev;
//     // td_u32 data;
//     td_s32 ot_ret;
//     td_u8 img_mode;
//     ot_isp_sns_state *pastisr2006 = TD_NULL;
//     isr2006_video_mode_tbl *isr2006_mode_tbl = TD_NULL;
//     // ot_isp_slave_sns_sync *isr2006_sync = isr2006_get_slave_sync(vi_pipe);
//     //td_s32 isr2006_bind_dev = isr2006_slave_bind_dev(vi_pipe);
//     //td_u32 isr2006_sensor_mode_time = isr2006_get_sensor_mode_time(vi_pipe);
//     ot_isp_sns_state *isr2006_sns_state = isr2006_get_ctx(vi_pipe);

//     pastisr2006 = isr2006_get_ctx(vi_pipe);
//     img_mode = pastisr2006->img_mode;
//     // slave_dev = isr2006_bind_dev;
//     // data = isr2006_sensor_mode_time;

//     isr2006_mode_tbl = isr2006_get_mode_tbl(img_mode);

//     // check_ret(ot_mpi_isp_get_sns_slave_attr(slave_dev, isr2006_sync));
//     // isr2006_sync->cfg.bits.bit_h_enable = 0;
//     // isr2006_sync->cfg.bits.bit_v_enable = 0;
//     // isr2006_sync->slave_mode_time = data;
//     // check_ret(ot_mpi_isp_set_sns_slave_attr(slave_dev, isr2006_sync));

//     ot_ret = isr2006_i2c_init(vi_pipe);
//     if (ot_ret != TD_SUCCESS)
//     {
//         isp_err_trace("i2c init failed!\n");
//         return;
//     }
//     // check_ret(ot_mpi_isp_get_sns_slave_attr(slave_dev, isr2006_sync));
//     // isr2006_sync->hs_time = isr2006_mode_tbl->inck_per_hs;

//     // if (isr2006_sns_state->regs_info[0].slv_sync.slave_vs_time == 0) {
//     //     isr2006_sync->vs_time = isr2006_mode_tbl->inck_per_vs;
//     // } else {
//     //     isr2006_sync->vs_time = isr2006_sns_state->regs_info[0].slv_sync.slave_vs_time;
//     // }
//     // isr2006_sync->cfg.bytes = 0xc0030000;
//     // isr2006_sync->hs_cyc = 0x3;
//     // isr2006_sync->vs_cyc = 0x3;
//     // check_ret(ot_mpi_isp_set_sns_slave_attr(slave_dev, isr2006_sync));

//     return;
// }

void isr2006_init(ot_vi_pipe vi_pipe)
{
    ot_wdr_mode wdr_mode;
    td_bool init;
    td_s32 ret;
    td_u8 img_mode;
    ot_isp_sns_state *pastisr2006 = TD_NULL;

    pastisr2006 = isr2006_get_ctx(vi_pipe);
    init = pastisr2006->init;
    wdr_mode = pastisr2006->wdr_mode;
    img_mode = pastisr2006->img_mode;

    // isr2006_set_slave_registers(vi_pipe);
    ret = isr2006_i2c_init(vi_pipe); // 初始化i2c,打开一个文件，并为它设定i2c地址，后续对i2c的操作通过读写文件完成
    if (ret != TD_SUCCESS)
    {
        isp_err_trace("i2c init failed!\n");
        return;
    }
    /* When sensor first init, config all registers */
    if (init == TD_FALSE)
    {
        if (OT_WDR_MODE_NONE == wdr_mode)
        {
            if (ISR2006_SENSOR_1936_1280_30FPS_12BIT_LINEAR_MODE == img_mode)
            { /* ISR2006_SENSOR_1936_1280_30FPS_12BIT_LINEAR_MODE */
                isr2006_linear_1936_1280_30_init(vi_pipe);
            }
        }
    }
    else
    {
        /* When sensor switch mode(linear<->WDR or resolution), config different registers(if possible) */
        if (OT_WDR_MODE_NONE == wdr_mode)
        {
            if (ISR2006_SENSOR_1936_1280_30FPS_12BIT_LINEAR_MODE == img_mode)
            { /* ISR2006_SENSOR_1936_1280_30FPS_12BIT_LINEAR_MODE */
                isr2006_linear_1936_1280_30_init(vi_pipe);
            }
        }
    }
    pastisr2006->init = TD_TRUE;
    return;
}

void isr2006_exit(ot_vi_pipe vi_pipe)
{
    td_s32 ret;
    ret = isr2006_i2c_exit(vi_pipe);
    if (ret != TD_SUCCESS)
    {
        isp_err_trace("isr2006 exit failed!\n");
    }
    return;
}
// #region

// static td_s32 isr2006_linear_4m30_part1(ot_vi_pipe vi_pipe)
// {
//     td_s32 ret = TD_SUCCESS;
//     ret += isr2006_write_register(vi_pipe, 0x3000, 0x01); /* STANDBY */
//     ret += isr2006_write_register(vi_pipe, 0x3002, 0x01); /* XTMSTA */

//     ret += isr2006_write_register(vi_pipe, 0x300C, 0x5B);
//     ret += isr2006_write_register(vi_pipe, 0x300D, 0x40);
//     ret += isr2006_write_register(vi_pipe, 0x30BE, 0x5E);
//     ret += isr2006_write_register(vi_pipe, 0x3110, 0x02);
//     ret += isr2006_write_register(vi_pipe, 0x314C, 0xC0);
//     ret += isr2006_write_register(vi_pipe, 0x315A, 0x06);
//     ret += isr2006_write_register(vi_pipe, 0x316A, 0x7E);
//     ret += isr2006_write_register(vi_pipe, 0x319E, 0x02);
//     ret += isr2006_write_register(vi_pipe, 0x3202, 0x02);
//     ret += isr2006_write_register(vi_pipe, 0x3288, 0x22);
//     ret += isr2006_write_register(vi_pipe, 0x328A, 0x02);
//     ret += isr2006_write_register(vi_pipe, 0x328C, 0xA2);
//     ret += isr2006_write_register(vi_pipe, 0x328E, 0x22);
//     ret += isr2006_write_register(vi_pipe, 0x3415, 0x27);
//     ret += isr2006_write_register(vi_pipe, 0x3418, 0x27);
//     ret += isr2006_write_register(vi_pipe, 0x3428, 0xFE);
//     ret += isr2006_write_register(vi_pipe, 0x349E, 0x6A);
//     ret += isr2006_write_register(vi_pipe, 0x34A2, 0x9A);
//     ret += isr2006_write_register(vi_pipe, 0x34A4, 0x8A);
//     ret += isr2006_write_register(vi_pipe, 0x34A6, 0x8E);
//     ret += isr2006_write_register(vi_pipe, 0x34AA, 0xD8);
//     ret += isr2006_write_register(vi_pipe, 0x3648, 0x01);
//     ret += isr2006_write_register(vi_pipe, 0x3678, 0x01);
//     ret += isr2006_write_register(vi_pipe, 0x367C, 0x69);
//     ret += isr2006_write_register(vi_pipe, 0x367E, 0x69);
//     ret += isr2006_write_register(vi_pipe, 0x3680, 0x69);
//     ret += isr2006_write_register(vi_pipe, 0x3682, 0x69);
//     ret += isr2006_write_register(vi_pipe, 0x371D, 0x05);
//     ret += isr2006_write_register(vi_pipe, 0x375D, 0x11);
//     ret += isr2006_write_register(vi_pipe, 0x375E, 0x43);
//     ret += isr2006_write_register(vi_pipe, 0x375F, 0x76);
//     ret += isr2006_write_register(vi_pipe, 0x3760, 0x07);
//     ret += isr2006_write_register(vi_pipe, 0x3768, 0x1B);
//     ret += isr2006_write_register(vi_pipe, 0x3769, 0x1B);
//     ret += isr2006_write_register(vi_pipe, 0x376A, 0x1A);
//     ret += isr2006_write_register(vi_pipe, 0x376B, 0x19);
//     ret += isr2006_write_register(vi_pipe, 0x376C, 0x17);
//     return ret;
// }

// static td_s32 isr2006_linear_4m30_part2(ot_vi_pipe vi_pipe)
// {
//     td_s32 ret = TD_SUCCESS;
//     ret += isr2006_write_register(vi_pipe, 0x376D, 0x0F);
//     ret += isr2006_write_register(vi_pipe, 0x376E, 0x0B);
//     ret += isr2006_write_register(vi_pipe, 0x376F, 0x0B);
//     ret += isr2006_write_register(vi_pipe, 0x3770, 0x0B);
//     ret += isr2006_write_register(vi_pipe, 0x3776, 0x89);
//     ret += isr2006_write_register(vi_pipe, 0x3777, 0x00);
//     ret += isr2006_write_register(vi_pipe, 0x3778, 0xCA);
//     ret += isr2006_write_register(vi_pipe, 0x3779, 0x00);
//     ret += isr2006_write_register(vi_pipe, 0x377A, 0x45);
//     ret += isr2006_write_register(vi_pipe, 0x377B, 0x01);
//     ret += isr2006_write_register(vi_pipe, 0x377C, 0x56);
//     ret += isr2006_write_register(vi_pipe, 0x377D, 0x02);
//     ret += isr2006_write_register(vi_pipe, 0x377E, 0xFE);
//     ret += isr2006_write_register(vi_pipe, 0x377F, 0x03);
//     ret += isr2006_write_register(vi_pipe, 0x3780, 0xFE);
//     ret += isr2006_write_register(vi_pipe, 0x3781, 0x05);
//     ret += isr2006_write_register(vi_pipe, 0x3782, 0xFE);
//     ret += isr2006_write_register(vi_pipe, 0x3783, 0x06);
//     ret += isr2006_write_register(vi_pipe, 0x3784, 0x7F);
//     ret += isr2006_write_register(vi_pipe, 0x3788, 0x1F);
//     ret += isr2006_write_register(vi_pipe, 0x378A, 0xCA);
//     ret += isr2006_write_register(vi_pipe, 0x378B, 0x00);
//     ret += isr2006_write_register(vi_pipe, 0x378C, 0x45);
//     ret += isr2006_write_register(vi_pipe, 0x378D, 0x01);
//     ret += isr2006_write_register(vi_pipe, 0x378E, 0x56);
//     ret += isr2006_write_register(vi_pipe, 0x378F, 0x02);
//     ret += isr2006_write_register(vi_pipe, 0x3790, 0xFE);
//     ret += isr2006_write_register(vi_pipe, 0x3791, 0x03);
//     ret += isr2006_write_register(vi_pipe, 0x3792, 0xFE);
//     ret += isr2006_write_register(vi_pipe, 0x3793, 0x05);
//     ret += isr2006_write_register(vi_pipe, 0x3794, 0xFE);
//     ret += isr2006_write_register(vi_pipe, 0x3795, 0x06);
//     ret += isr2006_write_register(vi_pipe, 0x3796, 0x7F);
//     ret += isr2006_write_register(vi_pipe, 0x3798, 0xBF);
//     ret += isr2006_write_register(vi_pipe, 0x3A18, 0x7F);
//     ret += isr2006_write_register(vi_pipe, 0x3A1A, 0x37);
//     ret += isr2006_write_register(vi_pipe, 0x3A1C, 0x37);
//     ret += isr2006_write_register(vi_pipe, 0x3A1E, 0xF7);
//     ret += isr2006_write_register(vi_pipe, 0x3A1F, 0x00);
//     ret += isr2006_write_register(vi_pipe, 0x3A20, 0x3F);
//     ret += isr2006_write_register(vi_pipe, 0x3A22, 0x6F);
//     ret += isr2006_write_register(vi_pipe, 0x3A24, 0x3F);
//     ret += isr2006_write_register(vi_pipe, 0x3A26, 0x5F);
//     ret += isr2006_write_register(vi_pipe, 0x3A28, 0x2F);
//     return ret;
// }

// #endregion

static td_s32 isr2006_linear_1936_1280_init_part(ot_vi_pipe vi_pipe)
{
    td_s32 ret = TD_SUCCESS;

    // isr2006 的 初始化 mipi 30fps 1936*1280  12bit

    // ret += isr2006_gpio_rst(11,7);

    ret += isr2006_write_register(vi_pipe, 0x007f, 0x00); // pll_pd = 0
    ret += isr2006_write_register(vi_pipe, 0x0082, 0x04); // pll_refdiv = 4
    ret += isr2006_write_register(vi_pipe, 0x0083, 0xc0); // pll_fbdiv = 0xc0
    ret += isr2006_write_register(vi_pipe, 0x0084, 0x05); // pll_div_adc = 5
    ret += isr2006_write_register(vi_pipe, 0x0086, 0x03); // pll_div_bitclk = 3
    ret += isr2006_write_register(vi_pipe, 0x0089, 0x05); // pll_div_pclk = 0x05
    ret += isr2006_write_register(vi_pipe, 0x008b, 0x05); // pll_div_cpclk = 0x05

    /*以上部分配置了pll 时钟 适用于 1936*1280 30fps 12bit mipi输出 模式*/

    // ret += isr2006_write_register(vi_pipe, 0x01df, 0x00); //

    ret += isr2006_write_register(vi_pipe, 0x01e0, 0x00);

    // ret += isr2006_write_register(vi_pipe, 0x01e1, 0x8f); //

    ret += isr2006_write_register(vi_pipe, 0x01e2, 0x07);

    ret += isr2006_write_register(vi_pipe, 0x00ac, (td_u8)ISR2006_HEIGHT);        // 高度 vmax 低位
    ret += isr2006_write_register(vi_pipe, 0x00ad, (td_u8)(ISR2006_HEIGHT >> 8)); // 高度 vmax 高位
    ret += isr2006_write_register(vi_pipe, 0x01e5, 0x00);                         // 不开启dol模式

    ret += isr2006_write_register(vi_pipe, 0x01e6, 0x00); // 配置输出模式为mipi
    ret += isr2006_write_register(vi_pipe, 0x01e7, 0x01); // 配置输出 bit_mode = 12bit
    ret += isr2006_write_register(vi_pipe, 0x01e8, 0x01); // 配置输出 timing_mode = 12bit

    ret += isr2006_write_register(vi_pipe, 0x00a5, 0x00);
    ret += isr2006_write_register(vi_pipe, 0x00a7, 0x00); // 曝光模式控制 0:内部寄存器曝光，1：外部控制曝光
    ret += isr2006_write_register(vi_pipe, 0x00a4, 0x00);

    ret += isr2006_write_register(vi_pipe, 0x00a9, 0x01); // 一次曝光触发输出的帧数量

    ret += isr2006_write_register(vi_pipe, 0x00aa, 0x00);
    ret += isr2006_write_register(vi_pipe, 0x00ab, 0x2d);

    ret += isr2006_write_register(vi_pipe, 0x008f, 0x08); // 曝光时间 低位 8行
    ret += isr2006_write_register(vi_pipe, 0x0090, 0x00); // 曝光时间 中间
    ret += isr2006_write_register(vi_pipe, 0x0091, 0x00); // 曝光时间 高位

    // ret += isr2006_write_register(vi_pipe, 0x00dc, 0xc0);

    // ret += isr2006_write_register(vi_pipe, 0x00de, 0xc0);

    // ret += isr2006_write_register(vi_pipe, 0x00d0, 0x01);

    // ret += isr2006_write_register(vi_pipe, 0x00d3, 0x00);

    // ret += isr2006_write_register(vi_pipe, 0x01de, 0x00);

    // ret += isr2006_write_register(vi_pipe,0x0092,(1280 + 12 - 200 -1)&(0x00ff)); //reg_a
    // ret += isr2006_write_register(vi_pipe,0x0093,(1280 + 12- 200 -1)>>8); // reg_a

    ret += isr2006_write_register(vi_pipe, 0x00e2, 0x01); // 开启了内部黑电平矫正
    ret += isr2006_write_register(vi_pipe, 0x00e3, 0x01); // 开启了黑电平统计
    ret += isr2006_write_register(vi_pipe, 0x00e4, 0x01); // 开启了ABLC 中值滤波器

    // ret += isr2006_write_register(vi_pipe, 0x00d0, 0x00); // 关闭row_dark_en

    ret += isr2006_write_register(vi_pipe, 0x014f, 0x00); //
    ret += isr2006_write_register(vi_pipe, 0x0143, 0x00);
    /*彩条 模式 使能 */

    ret += isr2006_write_register(vi_pipe, 0x0150, 0x00); // 不使能坏点矫正
    ret += isr2006_write_register(vi_pipe, 0x01d7, 0x00); // 不开启数字增益
    ret += isr2006_write_register(vi_pipe, 0x01d6, 0x00);
    ret += isr2006_write_register(vi_pipe, 0x0058, 0x01);
    ret += isr2006_write_register(vi_pipe, 0x0059, 0x0f);
    ret += isr2006_write_register(vi_pipe, 0x005a, 0x01);
    ret += isr2006_write_register(vi_pipe, 0x005b, 0x03);
    ret += isr2006_write_register(vi_pipe, 0x1201, 0xf0);
    ret += isr2006_write_register(vi_pipe, 0x1202, 0x70);
    ret += isr2006_write_register(vi_pipe, 0x1203, 0x10);
    ret += isr2006_write_register(vi_pipe, 0x1204, 0x10);
    ret += isr2006_write_register(vi_pipe, 0x1070, 0x02);
    ret += isr2006_write_register(vi_pipe, 0x1205, 0x00);
    ret += isr2006_write_register(vi_pipe, 0x1208, 0x01);
    ret += isr2006_write_register(vi_pipe, 0x1000, 0x10);
    ret += isr2006_write_register(vi_pipe, 0x1001, 0x00);
    ret += isr2006_write_register(vi_pipe, 0x1070, 0x12);
    ret += isr2006_write_register(vi_pipe, 0x1070, 0x02);

    ret += isr2006_write_register(vi_pipe, 0x1024, (td_u8)ISR2006_WIDTH); //
    ret += isr2006_write_register(vi_pipe, 0x1025, (td_u8)(ISR2006_WIDTH >> 8));
    ret += isr2006_write_register(vi_pipe, 0x1026, (td_u8)ISR2006_HEIGHT);
    ret += isr2006_write_register(vi_pipe, 0x1027, (td_u8)(ISR2006_HEIGHT >> 8));
    ret += isr2006_write_register(vi_pipe, 0x1040, 0x8d);
    ret += isr2006_write_register(vi_pipe, 0x1020, 0x2a);
    ret += isr2006_write_register(vi_pipe, 0x1042, 0x0f);
    ret += isr2006_write_register(vi_pipe, 0x1028, (td_u8)ISR2006_WIDTH);
    ret += isr2006_write_register(vi_pipe, 0x1029, (td_u8)(ISR2006_WIDTH >> 8));
    ret += isr2006_write_register(vi_pipe, 0x102a, (td_u8)ISR2006_HEIGHT);
    ret += isr2006_write_register(vi_pipe, 0x102b, (td_u8)(ISR2006_HEIGHT >> 8));
    ret += isr2006_write_register(vi_pipe, 0x102c, (td_u8)ISR2006_WIDTH);
    ret += isr2006_write_register(vi_pipe, 0x102d, (td_u8)(ISR2006_WIDTH >> 8));
    ret += isr2006_write_register(vi_pipe, 0x102e, (td_u8)ISR2006_HEIGHT);
    ret += isr2006_write_register(vi_pipe, 0x102f, (td_u8)(ISR2006_HEIGHT >> 8));
    ret += isr2006_write_register(vi_pipe, 0x1030, (td_u8)ISR2006_WIDTH);
    ret += isr2006_write_register(vi_pipe, 0x1031, (td_u8)(ISR2006_WIDTH >> 8));
    ret += isr2006_write_register(vi_pipe, 0x1032, (td_u8)ISR2006_HEIGHT);
    ret += isr2006_write_register(vi_pipe, 0x1033, (td_u8)(ISR2006_HEIGHT >> 8));
    ret += isr2006_write_register(vi_pipe, 0x01e3, 0x1e);

    ret += isr2006_write_register(vi_pipe, 0x00a4, 0x01); // 启用连续帧模式

    // ret += isr2006_write_register(vi_pipe, 0x1040, 0x8c);
    ret += isr2006_write_register(vi_pipe, 0x1040, 0x8d);
    ret += isr2006_write_register(vi_pipe, 0x005b, 0x03);
    ret += isr2006_write_register(vi_pipe, 0x005d, 0x0f);
    ret += isr2006_write_register(vi_pipe, 0x0042, 0xaa);
    ret += isr2006_write_register(vi_pipe, 0x009b, 0x00);
    ret += isr2006_write_register(vi_pipe, 0x009c, 0x00);
    ret += isr2006_write_register(vi_pipe, 0x009d, 0x00);
    ret += isr2006_write_register(vi_pipe, 0x009e, 0x00);

    ret += isr2006_write_register(vi_pipe, 0x00a5, 0x01); // 寄存器曝光使能

    ret += isr2006_write_register(vi_pipe, 0x00a6, 0x01); // 寄存器曝光触发信号  00a6 写0停流 写1再触发
    ret += isr2006_write_register(vi_pipe, 0x00a6, 0x00); // 寄存器曝光触发信号
    ret += isr2006_write_register(vi_pipe, 0x00a6, 0x01);
    ret += isr2006_write_register(vi_pipe, 0x0261, 0x0f);
    ret += isr2006_write_register(vi_pipe, 0x0262, 0x81);

    ret += isr2006_write_register(vi_pipe, 0x002b, 0x70);
    ret += isr2006_write_register(vi_pipe, 0x002c, 0x01);
    ret += isr2006_write_register(vi_pipe, 0x0030, 0x32);

    /*上述三行是模拟增益*/

    ret += isr2006_write_register(vi_pipe, 0x01d7, 0x01); // 开启数字增益

    ret += isr2006_write_register(vi_pipe, 0x01d8, 0x00); // 数字增益倍率 粗调 1倍

    ret += isr2006_write_register(vi_pipe, 0x0045, 0x88);
    ret += isr2006_write_register(vi_pipe, 0x0046, 0x7d);
    ret += isr2006_write_register(vi_pipe, 0x0150, 0x01);
    ret += isr2006_write_register(vi_pipe, 0x0090, (td_u8)(ISR2006_HEIGHT >> 8));
    ret += isr2006_write_register(vi_pipe, 0x008f, (td_u8)ISR2006_HEIGHT);
    ret += isr2006_write_register(vi_pipe, 0x0027, 0x01);
    ret += isr2006_write_register(vi_pipe, 0x0025, 0x08);

    ret += isr2006_write_register(vi_pipe, 0x01e9, 0x01); // 配置曝光时间精度为1行

    return ret;
}

/* 1936*1280 30fps */
static void isr2006_linear_1936_1280_30_init(ot_vi_pipe vi_pipe)
{
    td_s32 ret = TD_SUCCESS;
    ret +=isr2006_linear_1936_1280_init_part(vi_pipe);
    // ret += isr2006_linear_4m30_part1(vi_pipe);
    // ret += isr2006_linear_4m30_part2(vi_pipe);

    // isr2006_default_reg_init(vi_pipe);
    // if (vi_pipe == 1)
    // {
    //     ret += isr2006_write_register(vi_pipe, 0x3302, 0x4B);
    // }

    // ret += isr2006_write_register(vi_pipe, 0x3000, 0x00); /* standby */
    // delay_ms(18);                                         /* 18ms */
    // ret += isr2006_write_register(vi_pipe, 0x3002, 0x00); /* master mode start */
    if (ret != TD_SUCCESS)
    {
        isp_err_trace("write register failed!\n");
        return;
    }
    printf("===isr2006 1936*1280 30fps 12bit LINE Init OK!===\n");
    return;
}
